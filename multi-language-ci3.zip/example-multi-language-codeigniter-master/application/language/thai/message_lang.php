<?php 

$lang["menu_test"] = "ภาษาไทยเทสๆ";