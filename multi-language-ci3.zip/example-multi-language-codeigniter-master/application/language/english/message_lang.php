<?php 

$lang["menu_test"] = "English Test";